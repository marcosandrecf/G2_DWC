package com.dm.clube.business;

import com.dm.clube.infraestrutura.entidades.Atleta;
import com.dm.clube.infraestrutura.repositorios.AtletaRepositorio;
import org.springframework.stereotype.Service;


@Service
public class AtletaServicos {
    private final AtletaRepositorio repositorio;

    public AtletaServicos(AtletaRepositorio repositorio) {
        this.repositorio = repositorio;
    }

    public void salvarAtleta(Atleta atleta){
        repositorio.saveAndFlush(atleta);
    }

    public Atleta buscarAtletaporEmail(String email){

        return repositorio.findByEmail(email).orElseThrow(
                () -> new RuntimeException("Email não encontrado")
        );
    }

    public void deletarAtletaPorEmail(String email){
        repositorio.deleteByEmail(email);
    }

    public void atualizarAtletaPorId(Integer id, Atleta atleta) {
        Atleta atletaEntidade = repositorio.findById(id).orElseThrow(
                () -> new RuntimeException("Usuário não encontrado"));

        if (atleta.getEmail() != null) {
            atletaEntidade.setEmail(atleta.getEmail());
        }
        if (atleta.getNome() != null) {
            atletaEntidade.setNome(atleta.getNome());
        }
        repositorio.saveAndFlush(atletaEntidade);
    }

}
