package com.dm.clube.infraestrutura.repositorios;

import com.dm.clube.infraestrutura.entidades.Atleta;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AtletaRepositorio extends JpaRepository<Atleta, Integer> {

    Optional<Atleta> findByEmail(String email);

    @Transactional
    void deleteByEmail(String email);

}
