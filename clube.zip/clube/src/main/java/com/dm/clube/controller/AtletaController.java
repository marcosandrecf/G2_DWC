package com.dm.clube.controller;

import com.dm.clube.business.AtletaServicos;
import com.dm.clube.infraestrutura.entidades.Atleta;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/atleta")
@RequiredArgsConstructor
public class AtletaController {

    private final AtletaServicos atletaServicos;

    @PostMapping
    public ResponseEntity<Void> salvarAtleta(@RequestBody Atleta atleta){
        atletaServicos.salvarAtleta(atleta);
        return ResponseEntity.ok().build();
    }

    @GetMapping
    public ResponseEntity<Atleta> buscarAtletaPorEmail(@RequestParam String email){
        return ResponseEntity.ok(atletaServicos.buscarAtletaporEmail(email));
    }

    @DeleteMapping
    public ResponseEntity<Void> deletarAtletaPorEmail(@RequestParam String email){
        atletaServicos.deletarAtletaPorEmail(email);
        return ResponseEntity.ok().build();
    }

    @PutMapping
    public ResponseEntity<Void> atualizarAtletaPorId(@RequestParam Integer id,
                                                     @RequestBody Atleta atleta) {
        atletaServicos.atualizarAtletaPorId(id, atleta);
        return ResponseEntity.ok().build();
    }
}
