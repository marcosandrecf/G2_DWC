package com.dm.clube;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClubeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClubeApplication.class, args);
	}

}
