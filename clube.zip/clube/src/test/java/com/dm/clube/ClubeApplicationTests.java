package com.dm.clube;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClubeApplicationTests {

	@Test
	void contextLoads() {
	}

}
